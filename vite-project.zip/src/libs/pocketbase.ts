import PocketBase from 'pocketbase';

 const pb = new PocketBase('https://buylink.pockethost.io');
 export default pb